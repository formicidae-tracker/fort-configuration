#ifndef IOControlH
#define IOControlH IOControlH

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,8,18)
#define HAVE_UNLOCKED_IOCTL 1
#endif


#if HAVE_UNLOCKED_IOCTL
long hyperion_ioctl( struct file* file, unsigned int cmd, unsigned long arg );
#else
int hyperion_ioctl( struct inode* inode, struct file* file, unsigned int cmd, unsigned long arg );
#endif

#endif //IOControlH
