//-----------------------------------------------------------------------------
#ifndef InfoH
#define InfoH InfoH
//-----------------------------------------------------------------------------

#define COMPANY_NAME "MATRIX VISION GmbH"
#define COMPANY_WEBSITE "www.matrix-vision.com"
#define COMPANY_SUPPORT_MAIL "mailto:servicedesk@matrix-vision.de"
#define COMPANY_SUPPORT_SERVICEDESK "https://servicedesk.matrix-vision.com"
#define CURRENT_YEAR "2023"
#define VERSION_STRING "2.47.2.3496"

#endif // InfoH
