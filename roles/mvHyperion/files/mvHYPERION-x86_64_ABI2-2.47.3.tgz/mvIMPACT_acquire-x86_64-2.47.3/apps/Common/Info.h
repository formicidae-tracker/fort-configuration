//-----------------------------------------------------------------------------
#ifndef InfoH
#define InfoH InfoH
//-----------------------------------------------------------------------------

#define COMPANY_NAME wxT("MATRIX VISION GmbH")
#define COMPANY_WEBSITE wxT("www.matrix-vision.com")
#define COMPANY_SUPPORT_MAIL wxT("mailto:servicedesk@matrix-vision.de")
#define COMPANY_SUPPORT_SERVICEDESK wxT("https://servicedesk.matrix-vision.com")
#define CURRENT_YEAR wxT("2023")
#define VERSION_STRING wxT("2.47.2.3496")

#endif // InfoH
